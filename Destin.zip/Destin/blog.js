
// newsletter

let input = document.getElementById("input");
let btn = document.getElementById("btn");

btn.addEventListener("click", function() {
    input.value = "Thank you! Your submission has been received!";
    input.style.width = "400px";
    input.style.backgroundColor = " rgb(77, 140, 182)";
    input.style.fontSize = "16px";
    input.style.textAlign = "center";
    btn.style.display = "none";
    input.style.color ="white";
});



// testimonials

document.addEventListener('DOMContentLoaded', () => {
    const prevBtn = document.querySelector('.arrow1');
    const nextBtn = document.querySelector('.arrow2');
    const slideContainers = document.querySelectorAll('.slide1, .slide2, .slide3');
    
    let currentIndex = 0;
    
    function updateCarousel() {
        const slideWidth = slideContainers[0].offsetWidth;
        const slidesContainer = document.querySelector('.slide'); 
        slidesContainer.style.transform =`translateX(-${slideWidth * currentIndex}px)`;
    }
    
    nextBtn.addEventListener('click', () => {
        if (currentIndex < slideContainers.length - 1) {
            currentIndex++;
            updateCarousel();
        }
    });
    
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarousel();
        }
    });
});

