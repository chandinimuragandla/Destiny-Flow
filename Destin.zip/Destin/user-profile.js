document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the usual way
    document.getElementById('contact-form').style.display = 'none'; // Hide the form
    document.getElementById('thank-you-message').style.display = 'block'; // Show the thank you message
});